﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNETCore.Services
{
    public interface ISayHello
    {
        string Hi(string message);
    }
}

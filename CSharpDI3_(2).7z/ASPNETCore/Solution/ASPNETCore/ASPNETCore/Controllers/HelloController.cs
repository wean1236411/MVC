﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ASPNETCore.Models;
using ASPNETCore.Services;

namespace ASPNETCore.Controllers
{
    public class HelloController : Controller
    {
        ISayHello _SayHello;
        public HelloController(ISayHello sayHello)
        {
            _SayHello = sayHello;
        }

        public string Index()
        {
            var foo = _SayHello.Hi("Will");
            return foo;
        }
    }
}

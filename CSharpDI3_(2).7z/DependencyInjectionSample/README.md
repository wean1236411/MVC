
```sh
dotnet tool update --global dotnet-ef
```

```sh
dotnet add package Microsoft.EntityFrameworkCore.InMemory
```

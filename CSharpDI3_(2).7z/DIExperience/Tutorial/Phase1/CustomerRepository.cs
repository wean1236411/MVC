﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial.Phase1
{
    public class CustomerRepository
    {
        public void Save()
        {
            Console.WriteLine($"客戶紀錄已經更新");
        }
    }
}
